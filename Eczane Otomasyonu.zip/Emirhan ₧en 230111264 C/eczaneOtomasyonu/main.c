#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <time.h>
#include <stdbool.h>
#include <locale.h>

typedef struct Kullanici{
	char ad[20], 
	soyad[20], 
	kullaniciAdi[20], 
	parola[20],
	 parolaTekrar[20],
	 yoneticiKayit;

}kullanici;

typedef struct hasta{
     char tc[12];   
     char adSoyad[30];
     char cinsiyet;
     char adres [100];
     char tel[20];
     	
}hasta;

typedef struct ilac{
    char barkod[20];               
    char ilacAdi[20];
    char ureticiFirma[25];
    float fiyat;
    int adet;
   
    
}ilac;


typedef struct Belirti
{
	char no[20];
	char belirti[35];
}belirti;

typedef struct YanEtki
{
	char ilacno[20];
	char yanetkino[20];
}yanetki;


typedef struct satis {
   char hastaTC[12] ; 
   char ilacBarkod[20];   
   int adet;
   char tarih[10];
   float fiyat;
}satis;

void yeniKayitText(){
	printf("\n                              ******************");
	printf("\n                              *                *");
	printf("\n                              *  Yeni Kayit    *\n");
	printf("                              *                *\n");
	printf("                              ******************\n\n");
}

void kullaniciGirisText(){
	printf("\n                              ******************");
	printf("\n                              *                *");
	printf("\n                              *   Giris Yap    *\n");
	printf("                              *                *\n");
	printf("                              ******************\n\n");
}

void hataliGirisText(){
   	printf("\n\n\n\n\n\n                              >     Hatali giris. Lutfen gecerli bir sayi girin.     <\n\n");
	Sleep(1500);
    system("cls");
}




void BelirtilerMenusu()
{
		FILE *yDosya = fopen("yonetici.txt", "r");
	char yoneticiKontrol[2];
    fscanf(yDosya, " %[^\n]s",&yoneticiKontrol);
		printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              *Yan Etki Islemleri *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Yan Etki Listele                 <<<\n");
    printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |2| Yan Etki Ekle                    <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |3| Yan Etki Sil                     <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |4| Yan Etki Guncelle                <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |5| Ilac Yan Etki Ogren              <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Ana Menuye Don                   <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("            >>> LUTFEN SECIM YAPINIZ   :  ");
	int secim;

	
	if(scanf("%d",&secim)==1)
	{
		
		switch(secim)
		{
			case 1:
				system("cls");
				BelirtiListele();
				break;
			case 2: 
				system("cls");
				BelirtiEkle();
				break;
		
			case 3:
				system("cls");
				BelirtiSil();
				break;
			case 4: 
				 system("cls");
				 BelirtiGuncelle();
				 break;
			case 5:
				system("cls");
				IlacYanEtkiListele();
				break;
			case 0:
				system("cls");
				if(yoneticiKontrol[0] == '2'){//2 = personel
			ilacPersonelMenu();
			}else{
			ilacMenu();
			}
				break;
			
			default:
        system("cls");
       	printf("            ------------------------------------------------------------------\n");
        printf("            >>>               Gecersiz Secim. Tekrar Deneyin.              <<<\n");
        printf("            ------------------------------------------------------------------\n");
		
				Sleep(1000);
            	system("cls");
				Sleep(1000);
				ilacPersonelMenu();
				break;
		}
	}
	else
	{
			system("cls");
        	//printf("Hatali giris. Lutfen gecerli bir sayi girin.\n");       	
            printf("            ------------------------------------------------------------------\n");
        	printf("            >>>        Hatali giris. Lutfen gecerli bir sayi girin.        <<<\n");
        	printf("            ------------------------------------------------------------------\n");
			//Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            Sleep(1000);
            system("cls");
            ilacPersonelMenu();
	}
	
}
void YanEtkiEkle(char barkod[20])
{

	system("cls");
	Sleep(500);		
	struct YanEtki yt;
	BelirtilerIlacIcin();
	FILE *kayit = fopen("YanEtkiIlacKaydi.dat", "a+b");
	
		printf("Lutfen Ilac Kaydina Ait Yan Etkileri Giriniz  "); scanf(" %[^\n]s",yt.yanetkino);
		strcpy(yt.ilacno, barkod);
	
		Sleep(2200);
        fwrite(&yt, sizeof(struct YanEtki), 1, kayit);
        fclose(kayit);
        printf("Yan Etki kaydi yapildi.\n");
        Sleep(1000);
        system("cls");
        printf("1-) Devam\n0-)Ana Menuye Don \nDevam Etmek Istiyor musunuz?    :");
        char girdi[20];
        scanf("%s",girdi);
        Sleep(1000);
        system("cls");
        if(strcmp(girdi,"1")==0)
        {	
        	YanEtkiEkle(barkod);
		}
        else if(strcmp(girdi,"0")==0)
        {
        	//devam ediyor
		}
        else
        {
        	printf("Yanlis Girdi !!!\n");
			Sleep(1000);
			system("cls");
		}
        
	

	
}
void IlacYanEtkiListele()
{
	FILE *yDosya = fopen("yonetici.txt", "r");
	char yoneticiKontrol[2];
    fscanf(yDosya, " %[^\n]s",&yoneticiKontrol);
	system("cls"); 
	
   struct YanEtki yt;
    char ilacno[20];

    printf("            ---------------------------------------------------------------\n");
    printf("            >>>                   Yan Etki Listesi                       <<<\n");
    printf("            ---------------------------------------------------------------\n");
    printf("            >>>          Lutfen Ilac Barkodunu Giriniz                  <<<\n");
    scanf("%s", ilacno);

    Sleep(1000);
    system("cls");
    belirti belirtiler[100]; // �rnek olarak 100 belirti
    FILE *ptr = fopen("belirti.dat", "rb");
    int belirtiSayisi = 0;
    while (fread(&belirtiler[belirtiSayisi], sizeof(belirti), 1, ptr) == 1) {
        belirtiSayisi++;
    }
    fclose(ptr);
    FILE *kayit = fopen("YanEtkiIlacKaydi.dat", "rb");
    printf("            ---------------------------------------------------------------\n");
    printf("            >>>                   Yan Etki Listesi                       <<<\n");
    
	int i=0;
    while (fread(&yt, sizeof(struct YanEtki), 1, kayit) == 1) {
        if (strcmp(yt.ilacno, ilacno) == 0) {
            for ( i= 0; i < belirtiSayisi; i++) {
                if (strcmp(yt.yanetkino, belirtiler[i].no) == 0) {
   printf("            ---------------------------------------------------------------\n");
    printf("            >>>                          %s\n                                  \n", belirtiler[i].belirti );
   
                    
                }
            }
        }
    
	}

   		 fclose(kayit);
		char tus;
		printf("            >>> LUTFEN BIR TUSA BASINIZ    :  ");
		tus=_getch();
		system("cls");
		if(yoneticiKontrol[0] == '2'){//2 = personel
		ilacPersonelMenu();
		}else{
		ilacMenu();
		}
		
}


void BelirtiEkle()
{      belirti h1;
	
		printf("            ----------------------------------------------------------------\n");
        printf("            >>>                       Yan Etki Islemleri                  <<<\n");
        printf("            ----------------------------------------------------------------\n");
        printf("            >>>                       Yan Etki No:  "); 					
		
		scanf(" %[^\n]s",&h1.no);
        printf("            ----------------------------------------------------------------\n");
        printf("            >>>                       Yan Etki Giriniz:  "); 					
		scanf(" %[^\n]s",&h1.belirti);    
        printf("            ----------------------------------------------------------------\n");
        

Sleep(1500);

system("cls");
FILE *ptr=fopen("belirti.dat","a+b");

fwrite(&h1,sizeof(belirti),1,ptr);
fclose(ptr);

system("cls");



printf("            ----------------------------------------------------------------\n");
printf("            >>>                       Islem Basarili                     <<<\n");
printf("            >>>                Menuye Yonlendiriliyorsunuz...            <<<\n");
printf("            ----------------------------------------------------------------\n");

Sleep(2000);
system("cls");
BelirtilerMenusu();

}

void BelirtilerIlacIcin()
{
		
	belirti h1;
	
		printf("            ----------------------------------------------------------------\n");
        printf("            >>>                       Yan Etki Listesi                    <<<\n");
        printf("            ----------------------------------------------------------------\n");
	
	FILE *bptr =fopen("belirti.dat","r+b");

	while( fread(&h1,sizeof(belirti),1,bptr)!=NULL )
	{
		 printf("                          %s %s                         \n",h1.no,h1.belirti);
	//	printf("%s %s\n",h1.no,h1.belirti);
	}
 printf("            ----------------------------------------------------------------\n");
	fclose(bptr);
}


void BelirtiListele()
{
	char tus;
	belirti h1;
		printf("            ----------------------------------------------------------------\n");
        printf("            >>>                       Yan Etki Listesi                    <<<\n");
        printf("            ----------------------------------------------------------------\n");
	
	FILE *ptr =fopen("belirti.dat","r+b");
	
	while( fread(&h1,sizeof(belirti),1,ptr)!=NULL )
	{
		
        printf("                          %s %s                         \n",h1.no,h1.belirti);
        
	//	printf("%s %s\n",h1.no,h1.belirti);
	}
	printf("            ----------------------------------------------------------------\n");

	fclose(ptr);
		printf(" >>> LUTFEN BIR TUSA BASINIZ    :  ");
tus=_getch();
system("cls");
//printf("\nMenuye Yonlendiriliyorsunuz");
printf("            ----------------------------------------------------------------\n");
printf("            >>>                Menuye Yonlendiriliyorsunuz...            <<<\n");
printf("            ----------------------------------------------------------------\n");
Sleep(2000);
system("cls;");
BelirtilerMenusu();
}


void BelirtiSil()
{
		printf("            ----------------------------------------------------------------\n");
        printf("            >>>                       Yan Etki Silme                      <<<\n");
        printf("            ----------------------------------------------------------------\n");

	char hastano[20];
	belirti h1;
	int sonuc=0;
	
	 printf(" >>>                       Yan Etki No:  "); 					
		
		scanf("%s",hastano);
        printf("            ----------------------------------------------------------------\n");
	
	
	FILE *ptr= fopen("belirti.dat","r+b");
	FILE *yptr=fopen("belirtiyedek.dat","w+b");
	
	while( fread(&h1, sizeof(belirti), 1, ptr)!=NULL )
	{
		if(strcmp(hastano,h1.no)!=0)				
		fwrite(&h1,sizeof(belirti),1,yptr);
		
		else
		{
			sonuc=1;
		}
		
		
		
	}
	fclose(ptr);
	fclose(yptr);
	
	if( sonuc == 1 )
	{
	remove("belirti.dat"); 
	rename("belirtiyedek.dat","belirti.dat" ); 
	//printf("Belirti Silindi \n"); 
	
	printf("            >>>                      Yan Etki Silindi                     <<<\n");
	printf("            ----------------------------------------------------------------\n");

	Sleep(2000);
	system("cls");
	//printf("Menuye Yonlendiriliyorsunuz\n");
	printf("            ----------------------------------------------------------------\n");
	printf("            >>>                Menuye Yonlendiriliyorsunuz...            <<<\n");
    printf("            ----------------------------------------------------------------\n");
	Sleep(2000);
	system("cls");
	BelirtilerMenusu();
	}
	else
	{
	
	//printf("Belirti kaydiniz bulunamadi !\n") ; 		
	//printf("\nMenuye Yonlendiriliyorsunuz");
	printf("            ----------------------------------------------------------------\n");
	printf("            >>>               Yan Etki kaydiniz bulunamadi!               <<<\n");
	printf("            >>>               Menuye Yonlendiriliyorsunuz...              <<<\n");
    printf("            ----------------------------------------------------------------\n");
	Sleep(2000);
	system("cls");
	BelirtilerMenusu();
	
	}
}



void BelirtiGuncelle()
{
	
	belirti h1;
	char hastano[20];
	char yeniAd[35];
	int sonuc=0;
	int sayac=0;
	
	
		printf("            ----------------------------------------------------------------\n");
        printf("            >>>                       Yan Etki Guncelleme                 <<<\n");
        printf("            ----------------------------------------------------------------\n");
		printf("            >>>                       Yan Etki No:  "); 					
		
		scanf("%s",hastano);
        printf("            ----------------------------------------------------------------\n");

	
	FILE *ptr=fopen("belirti.dat","r+b");
	
	while( fread(&h1,sizeof(belirti),1,ptr)!=NULL)
	{
		
		if(strcmp(hastano,h1.no)==0)
		{
			sonuc=1;
			system("cls");
			//printf("No : %s\nYan Etki :%s",h1.no,h1.belirti);
			printf("\n           >>>                       No : %s ",h1.no);
			printf("\n           >>>                       Yan Etki : %s ",h1.belirti);
			break;
		}
		sayac++;
	}
	
	if(sonuc==0)
	{
		//printf("Boyle Bir No Yok\n");
		printf("            >>>                     Boyle Bir No Yok                     <<<\n");
    	printf("            ----------------------------------------------------------------\n");
		fclose(ptr);	
		Sleep(1000);

		system("cls");
		//printf("Menuye Yonlendiriliyorsunuz");
		printf("            ----------------------------------------------------------------\n");
		printf("            >>>                Menuye Yonlendiriliyorsunuz...            <<<\n");
	    printf("            ----------------------------------------------------------------\n");
		Sleep(2000);
		system("cls");


		BelirtilerMenusu();
	}
	
	else
	{
		//printf("\nYeni Ismi Giriniz  :"); 
		printf("\n            ----------------------------------------------------------------\n");
		printf("               >>>                       Yeni Ismi Giriniz :  ");
		scanf("%s",yeniAd);
		rewind(ptr);
		
		strcpy(h1.belirti,yeniAd);
		fseek(ptr,(sayac)*sizeof(belirti),0);
		fwrite(&h1,sizeof(belirti),1,ptr);
		fclose(ptr);
		//printf("Guncelleme Tamamland�");
		printf("            ----------------------------------------------------------------\n");
		printf("            >>>                  Guncelleme Tamamlandi                   <<<\n");
	    printf("            ----------------------------------------------------------------\n");
		Sleep(1000);
		system("cls");
		//printf("Menuye Yonlendiriliyorsunuz");
		printf("            ----------------------------------------------------------------\n");
		printf("            >>>                Menuye Yonlendiriliyorsunuz...            <<<\n");
	    printf("            ----------------------------------------------------------------\n");
		Sleep(2000);
				system("cls");

		BelirtilerMenusu();
	
	}
	
	
}





void kullaniciGiris(){
	int sonuc = 0;
	static int deneme = 0;
	int denemehakki = 2;
	char kullaniciAdi[20], parola[20];
	FILE *ptr = fopen("kullanicilar.dat", "r+b");
	struct Kullanici k1;
	if(ptr==NULL){
		system("cls");
		printf("\n\n\n\n\n\n                              >     Veritabaninda Kayitli Kullanici Bulunamadi    <\n");
		printf("                              >     Ana Menuye Yonlendiriliyorsunuz >");
		Sleep(1500); // x milisaniye bekletmek i�in kullan�l�r
		printf(">");
		Sleep(1000);
		printf(">\n\n");
		Sleep(1000);
		system("cls");
		girisMenu();
	}
	
	printf("                         ___________________________________\n");
	printf("                         >> Kullanici Adi :"); scanf(" %[^\n]s", kullaniciAdi);
	printf("                         ___________________________________\n");
	printf("                         >> Parola        :"); scanf(" %[^\n]s", parola);	
	
	while((fread(&k1, sizeof(struct Kullanici), 1, ptr)) !=NULL){
	if( strcmp( kullaniciAdi, k1.kullaniciAdi) ==0 ){
		if(strcmp(parola,k1.parola) == 0){
			FILE *ydosya = fopen("yonetici.txt", "w");
			FILE *dosya = fopen("aktifkullanici.txt", "w");
            fclose(ydosya);
			fclose(dosya);
			printf("                         >> Giris Basarili \n\n");
			system("cls");
			FILE *yptr = fopen("yonetici.txt", "a");
			fprintf(yptr," %c", k1.yoneticiKayit);
			fclose(yptr);
			
			FILE *aptr = fopen("aktifkullanici.txt", "a");
			fprintf(aptr," %s %s", k1.ad, k1.soyad);
			fclose(aptr);
			if(k1.yoneticiKayit == '1'){
			yoneticiAnaMenu();
			}else if(k1.yoneticiKayit == '2'){
			personelAnaMenu();
			}
			sonuc = 1;
			break;		
			}
		}
	}	
	
	if(sonuc == 0 && ptr!=NULL){
		if(deneme<2){
			system("cls");
			kullaniciGirisText();
			denemehakki = denemehakki - deneme;
			printf("                    >     Kullanici adi ve ya parola hatali tekrar deneyiniz   <\n");
			printf("                    >     kalan deneme hakki : %d \n", denemehakki);
		}
		
		deneme++;
		
		if(deneme==3){
		system("cls");
		printf("\n\n\n\n\n\n               >     kalan deneme hakki : 0   <\n");
		printf("               >     Cok fazla hatali  giris yaptiniz Ana Sayfaya Yonlendiriliyorsunuz >");
		Sleep(1500);
		printf(">");
		Sleep(1500);
		printf(">");
		system("cls");
		girisMenu();
		return 0;
		}
		
		kullaniciGiris();
	}
}

void hastaMenu(){
	struct Kullanici k1;
	int secim;
	printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              * Hasta Islemleri *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Hasta Kaydi                <<<\n");
    printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |2| Hastalari Listele          <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |3| Hasta Sil                  <<<\n");
	printf("           ----------------------------------------------------------------\n");
 	printf("           >>>                     |0| Ana Menuye Don             <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("\n           |Seciminizi girin : ");
    
	if(scanf("%d", &secim) == 1){
	
	switch (secim) {
            case 1:
                hastaKaydi();
                break;
            case 2:
                hastaListele();
                break;
            case 3:
				hastaSil();
				break;
            case 0:
                system("cls");
                yoneticiAnaMenu();
            default:
            	system("cls");
				hataliGirisText();
				hastaMenu();
        }
    }else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            system("cls");
            hastaMenu();
		}
}

void hastaPersonelMenu(){
	struct Kullanici k1;
	FILE *yDosya = fopen("yonetici.txt", "r");
	char yoneticiKontrol[2];
    fscanf(yDosya, " %[^\n]s",&yoneticiKontrol);
	int secim;
	printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              * Hasta Islemleri *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Hasta Kaydi                <<<\n");
    printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |2| Hastalari Listele          <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Ana Menuye Don             <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("\n           |Seciminizi girin : ");
    
	if(scanf("%d", &secim) == 1){
	
	switch (secim) {
            case 1:
                hastaKaydi();
                break;
            case 2:
                hastaListele();
                break;
            case 0:
                system("cls");
                personelAnaMenu();
            default:
            	system("cls");
				hataliGirisText();
				hastaPersonelMenu();
        }
    }else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            system("cls");
            hastaPersonelMenu();
		}
}

	void yeniKayit(){
	struct Kullanici k1;
	printf("                         ___________________________________\n");
	printf("                         >> AD            : "); scanf(" %[^\n]s", k1.ad); 	//ad
	printf("                         ___________________________________\n");
	printf("                         >> Soyad         : "); scanf(" %[^\n]s", k1.soyad);  //soyad
	printf("                         ___________________________________\n");
	printf("                         >> Kullanici Adi : "); scanf(" %[^\n]s", k1.kullaniciAdi);   //kullan�c� ad�
	printf("                         ___________________________________\n");
	
	if (strchr(k1.kullaniciAdi, ' ') != NULL) {
		system("cls");
		printf("\n\n\n\n\n\n                         ! ! !   Kullanici adinda bosluk kullanilamaz. Tekrar deneyiniz   !!!\n");
        Sleep(2500);
        system("cls");
        yeniKayitText();
        yeniKayit();
    }
	printf("                         >> Parola        : "); scanf(" %[^\n]s", k1.parola);		//parola
	
	printf("\n\n                         --------------------");
	printf("\n                         |Yonetici |1|");
	printf("\n                         --------------------");
	printf("\n                         |Personel |2|\n");
	printf("                         --------------------\n");
	printf("                         Seciminiz :");
	
	k1.yoneticiKayit;
    k1.yoneticiKayit = getch();
    printf("%c",k1.yoneticiKayit);
    Sleep(500);
	
	int verilenKod=1234;
	int kullanici_kontrol = 0;
	struct Kullanici kullanici_adi;
	
	
	FILE *ptr= fopen("kullanicilar.dat", "r+b") ;
	if(ptr!=NULL){
		while( fread(&kullanici_adi, sizeof(struct Kullanici), 1, ptr) !=NULL  ){
			if(strcmp(k1.kullaniciAdi, kullanici_adi.kullaniciAdi) == 0){
		kullanici_kontrol = 1;
	}
		}
			}
	if(k1.yoneticiKayit == '1'){
	int yoneticiKod;
	printf("\n\n                      >>> Lutfen Sistem Saglayiciniz Tarafindan Verilen kodu Giriniz :");
	scanf("%d",&yoneticiKod);
	if(yoneticiKod == verilenKod){
	printf("                      >>> Yonetici Girisi Basarili\n");
	Sleep(1000);		
	}else{printf("                      >>>Hatali Kod Girisi, Lutfen Sistem Saglayicinizla �letisime Geciniz !!!");
	Sleep(1500);
	system("cls");
	girisMenu();
	}
	}else if(k1.yoneticiKayit == '2'){
		printf("\n                      >>>Personel Kayit Islemi Basarili\n");
		
	}else {
		printf("\n                      >>>Farkli Tus Girisi !!! Giris Menusune Yonlendiriliyorsunuz...");
		girisMenu();
	}	
	int n = strlen(k1.parola);
	if(n<6){
		system("cls");
		printf("\n\n\n\n\n\n                         ! ! !   Parola uzunlugu 6 karakter olmalidir, lutfen tekrar deneyiniz ! ! ! \n");
		Sleep(2500);
		system("cls");
		yeniKayitText();
		yeniKayit();
			
	}else if(kullanici_kontrol == 1){
		system("cls");
		printf("\n\n\n\n\n\n                         ! ! !   Bu kullanici adi baska kullaniciya ait. Lutfen tekrar deneyiniz. ! ! ! \n");
		Sleep(2500);
		system("cls");
		yeniKayitText();
		yeniKayit();
	}else{
	FILE *ptr = fopen("kullanicilar.dat", "a+b");
	if(ptr!=NULL){
		fwrite (&k1, sizeof(struct Kullanici),1,ptr);
				fclose(ptr);
					printf("                         ___________________________________\n");
					Sleep(1000);
					printf("\n                         Ana ");
					Sleep(500);
					printf("Menuye ");
					Sleep(500);
					printf("Yonlendiriliyorsunuz ");
					Sleep(500);
					printf(">");
					Sleep(1000);
					printf(">");
					Sleep(1000);
					printf(">");
					Sleep(1000);
					system("cls");
					main();
			
			}else{
				system("cls");
			printf("\n                         >> Kayit i�leminde veri tabani hatasi !!! \n");
			Sleep(1000);
			main();
			}
		}
}

void girisMenu(){
    	printf(" ----------------------------------------------------------------\n");
        printf(" >>>                     |1| Giris Yap                        <<<\n");
        printf(" ----------------------------------------------------------------\n");
        printf(" >>>                     |2| Yeni Kayit                       <<<\n");
        printf(" ----------------------------------------------------------------\n");
		printf(" >>>                     |0| Programi kapat                   <<<\n");
		printf(" ----------------------------------------------------------------\n");
        printf("\n |Seciminizi girin : ");
        char secim ;
        secim = getch();
        printf("%c",secim);
        Sleep(500);
        	switch (secim) {
            case '1':
            	system("cls");
            	kullaniciGirisText();
                kullaniciGiris();
                break;
            case '2':
            	system("cls");
            	yeniKayitText();
                yeniKayit();
                break;
            case '0':
            	system("cls");
                printf("\n\n\n\n\n\n           ----------------------------------------------------------------\n");
				printf("           ----------------------------------------------------------------\n");
				printf("                                   Program Kapatildi...                 \n");
				printf("           ----------------------------------------------------------------\n");
				printf("           ----------------------------------------------------------------\n");
                exit(0);
            default:
            	system("cls");
            	hataliGirisText();
            	girisMenu();
            	
				}	
}

void yoneticiAnaMenu(){
	int secim;

	FILE *aktifDosya = fopen("aktifkullanici.txt", "r");
	char adSoyad[40];
    fscanf(aktifDosya, " %[^\n]s", adSoyad);
    printf("\n                              ******************");
	printf("\n                              *                *");
	printf("\n                              *   Hosgeldiniz  *");
	printf("\n                              *   %s  *\n",adSoyad);
	printf("                              *                *\n");
	printf("                              ******************\n\n");
	
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Satis Islemleri                  <<<\n");
    printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |2| Hasta Islemleri                  <<<\n");
    printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |3| Ilac Islemleri                   <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |4| Personel Islemleri               <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |5| Cari Islemler                    <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Kullanici Cikis                  <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("\n           |Seciminizi girin : ");
        
    if(scanf("%d", &secim) == 1){
        switch (secim) {
            case 1:
            	system("cls");
                satisMenu();
                break;
            case 2:
            	system("cls");
                hastaMenu();
                break;
            case 3:
            	system("cls");
                ilacMenu();
                break;
            case 4:
			    system("cls");
			    personelListele();
			    break;
			case 5:
				system("cls");
				cariIslemlerMenu();
				break;
            case 0:
            	system("cls");
            	printf("\n\n\n\n               >     Kullanici cikisi yapiliyor >");
				Sleep(750);
				printf(">");
				Sleep(750);
				printf(">");
				FILE *dosya = fopen("aktifkullanici.txt", "w");
				fclose(dosya);
				Sleep(500);
				system("cls");
				girisMenu();
				break;
			default:
		    	system("cls");
				hataliGirisText();
				yoneticiAnaMenu();
				break;
				}
        	}else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            yoneticiAnaMenu();
			}
		
}


void personelAnaMenu(){
	int secim;
	FILE *aktifDosya = fopen("aktifkullanici.txt", "r");
	char adSoyad[40];
    fscanf(aktifDosya, " %[^\n]s", adSoyad);
    printf("\n                              ******************");
	printf("\n                              *                *");
	printf("\n                              *   Hosgeldiniz  *");
	printf("\n                              *   %s  *\n",adSoyad);
	printf("                              *                *\n");
	printf("                              ******************\n\n");
	
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Satis Islemleri                  <<<\n");
    printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |2| Hasta Islemleri                  <<<\n");
    printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |3| Ilac Islemleri                   <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Kullanici Cikis                  <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("\n           |Seciminizi girin : ");
        
    if(scanf("%d", &secim) == 1){
        switch (secim) {
            case 1:
            	system("cls");
                satisPersonelMenu();
                break;
            case 2:
            	system("cls");
                hastaPersonelMenu();
                break;
            case 3:
            	system("cls");
                ilacPersonelMenu();
                break;
            case 0:
            	system("cls");
            	printf("\n\n\n\n               >     Kullanici cikisi yapiliyor >");
				Sleep(750);
				printf(">");
				Sleep(750);
				printf(">");
				FILE *dosya = fopen("aktifkullanici.txt", "w");
				fclose(dosya);
				Sleep(500);
				system("cls");
				girisMenu();
				break;
			default:
		    	system("cls");
				hataliGirisText();
				personelAnaMenu();
				break;
				}
        	}else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            personelAnaMenu();
			}
		
}

void personelListele() {
	system("cls") ;
	char tus; 
	printf("\n                             | Personel Listesi |\n\n") ; 
	kullanici k1; 
	FILE *ptr= fopen("kullanicilar.dat", "r+b" ) ; 
	
		printf( " |%-12s |%-12s| %-20s\n\n", "AD", "SOYAD", "KULLANCI ADI"); 
	while( fread( &k1, sizeof(kullanici ), 1, ptr ) !=NULL){
		printf(">> %-12s %-12s %-20s\n",k1.ad, k1.soyad, k1.kullaniciAdi) ;
		}
		fclose(ptr);
		printf("\n\n\n\n >> Ana Menuye gitmek icin herhangi bir tusa basiniz : ");
		tus = _getch();
		system("cls");
		yoneticiAnaMenu();

		
}

void cariIslemlerMenu(){
	int secim;
	printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              * Cari Islemler  *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Satislari Raporla          <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Ana Menuye Don             <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("\n           |Seciminizi girin : ");
	if(scanf(" %d", &secim)){
	
	switch (secim) {
            case 1:
                satisRaporla();
                break;
            case 0:
                system("cls");
                yoneticiAnaMenu();
            default:
            	system("cls");
				hataliGirisText();
				system("cls");
				cariIslemlerMenu();
        }
        }else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            system("cls");
            satisMenu();
		}
}

//******************************************************
void satisMenu(){
	int secim;
	printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              * Satis Islemleri *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Satis Yap                  <<<\n");
    printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Ana Menuye Don             <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("\n           |Seciminizi girin : ");
	if(scanf(" %d", &secim)){
	
	switch (secim) {
            case 1:
                satisYap();
                break;
            case 0:
                system("cls");
                yoneticiAnaMenu();
            default:
            	system("cls");
				hataliGirisText();
				system("cls");
				satisMenu();
        }
        }else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            system("cls");
            satisMenu();
		}
}

void satisPersonelMenu(){
	int secim;
	printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              * Satis Islemleri *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Satis Yap                  <<<\n");
    printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Ana Menuye Don             <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("\n           |Seciminizi girin : ");
	if(scanf(" %d", &secim)){
	
	switch (secim) {
            case 1:
                satisYap();
                break;
            case 0:
                system("cls");
                personelAnaMenu();
            default:
            	system("cls");
				hataliGirisText();
				system("cls");
				satisPersonelMenu();
        }
        }else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            system("cls");
            satisPersonelMenu();
		}
}

void updateStock(char barkod[20], int satilanMiktar) {
    ilac i1;
    FILE *ptr = fopen("ilaclar.dat", "r+b");

    if (ptr != NULL) {
        while (fread(&i1, sizeof(ilac), 1, ptr) != NULL) {
            if (strcmp(barkod,i1.barkod) == 0) {
                if (i1.adet >= satilanMiktar) {
                    i1.adet -= satilanMiktar;
                    fseek(ptr, -sizeof(ilac), SEEK_CUR);
                    fwrite(&i1, sizeof(ilac), 1, ptr);
                    printf("\n                      >> Stok Guncellendi: %d adet %s\n", satilanMiktar, i1.ilacAdi);
                } else {
                    printf("Hata: Stokta yeterli miktarda ilac yok!\n");
                }
                break;
            }
        }
        fclose(ptr);
    }
}



void satisYap(){
	FILE *yDosya = fopen("yonetici.txt", "r");
	char yoneticiKontrol[2];
    fscanf(yDosya, " %[^\n]s",&yoneticiKontrol);
	system("cls"); 
	printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              *  Satis Ekrani   *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	
	satis s1;
	hasta h1; 
	ilac i1; 
	int hsonuc=0, isonuc=0; 
	printf("                         ___________________________________\n");
	printf("                         >> Hasta TC     : ") ; scanf(" %[^\n]s", s1.hastaTC ); 	
	printf("                         ___________________________________\n");
	printf("                         >> Ilac Barkod  : ") ; scanf(" %[^\n]s", s1.ilacBarkod); 
	printf("                         ___________________________________\n");
	printf("                         >> Adet (Kutu)  : ") ; scanf("%d", &s1.adet ); 
	printf("                         ___________________________________\n");
	
	FILE *hptr= fopen("hastalar.dat", "r+b") ; 
	FILE *iptr= fopen("ilaclar.dat", "r+b") ;
	
	while(fread(&h1, sizeof(hasta), 1, hptr) !=NULL  ){
		if(strcmp(s1.hastaTC, h1.tc) ==0){
			hsonuc=1;
			break;
		}				
	}
	
	while(fread(&i1, sizeof(ilac), 1, iptr) !=NULL){
		if(strcmp(s1.ilacBarkod, i1.barkod) ==0){
			isonuc=1;
			break; 
		}				
	}
	fclose(iptr); 
	fclose(hptr);
	
	if( hsonuc==0)
	{
		printf("                         >> Hatali TC numarasi !\n") ;
		printf("                         >> Bilgileri kontrol edip tekrar deneyiniz!!!\n") ;
		Sleep(2000);
        system("cls");
        
    	if(yoneticiKontrol[0] == '2'){//2 = personel
		satisPersonelMenu();
		}else{
		satisMenu();
		}
		return ; 
	}
	if( isonuc==0){
		printf("                         >> Hatali barkod numarasi !\n") ; 
		printf("                         >> Bilgileri kontrol edip tekrar deneyiniz!!!\n") ;
		Sleep(2000);
        system("cls");
		if(yoneticiKontrol[0] == '2'){//2 = personel
		satisPersonelMenu();
		}else{
		satisMenu();
		}
		return ; 
	}
	if(  s1.adet > i1.adet ){
		printf("                         >> Stokta yeterli miktarda ilac yok !\n") ; 
		printf("                         >> Bilgileri kontrol edip tekrar deneyiniz!!!\n") ;
		Sleep(2000);
        system("cls");
		if(yoneticiKontrol[0] == '2'){//2 = personel
		satisPersonelMenu();
		}else{
		satisMenu();
		}
		return ; 
	}
	float toplamFiyat; 
	toplamFiyat= s1.adet * i1.fiyat; 
	printf("\n                         >> Toplam ucret: %.2f TL \n", toplamFiyat ); 
	char satisTus;
    printf("\n\n           >> Satis Iptal > 1 < || Devam > Diger Tuslar < : ");
	satisTus = _getch();
	printf("%c \n",satisTus);
	Sleep(1500);
	if(satisTus == '1'){
		system("cls");
		if(yoneticiKontrol[0] == '2'){//2 = personel
			satisPersonelMenu();
		}else{
			satisMenu();
	}
	}
	FILE * sptr= fopen("satislar.txt", "a" ); 
	time_t satisTarihi= time(NULL); 
	printf("                         ___________________________________\n");
	printf("\n                         >>     Satis islemi tamam     <<\n");
	FILE *aktifDosya = fopen("aktifkullanici.txt", "r");
	char adSoyad[40];
   	fscanf(aktifDosya, " %[^\n]s", adSoyad);
   	printf("                         ___________________________________\n");
		
	fprintf( sptr, "\n\n                         ___________________________________\n\n"    ) ; 	
	fprintf( sptr, "                         Satis Tarihi   : %s \n", ctime(&satisTarihi)     ) ; 
	fprintf( sptr, "                         Kisi Bilgileri : %s\t%s\t%s\n", h1.tc, h1.adSoyad, h1.tel);
	fprintf( sptr, "                         Ilac Bilgileri : %s\t%s\n", i1.barkod, i1.ilacAdi) ; 
	fprintf( sptr, "                         Ucret Bilgileri [adet/fiyat/toplamucret] : %d\t%f\t%f\n", s1.adet, i1.fiyat, toplamFiyat);
	fprintf( sptr, "                         Satisi yapan    : %s\n", adSoyad);
	fclose(sptr);

	if (toplamFiyat > 0) {
    	updateStock(s1.ilacBarkod, s1.adet);
	}		
		
    char tus;
    printf("\n\n >> Satis Menusune gitmek icin herhangi bir tusa basiniz : ");
	tus = _getch();
	system("cls");
	if(yoneticiKontrol[0] == '2'){//2 = personel
		satisPersonelMenu();
	}else{
		satisMenu();
	}
			
	
}

void satisRaporla() {
    system("cls"); 
    char tus;
	printf("\nSatis rapor ekrani\n\n") ; 
	FILE *ptr= fopen("satislar.txt", "r"); 
	char ch; 
	
	if( ptr!=NULL ){
	
	while( !feof(ptr) ){
		ch= fgetc(ptr); 
		printf("%c", ch); 
		}
		fclose(ptr);
		printf("\n\n\n\n >> Cari Islemler Menusune Gitmek Icin Herhangi Bir Tusa Basiniz : ");
		tus = _getch();
		system("cls");
		cariIslemlerMenu();
 }	else{
 	int sure;
 	for(sure = 3; sure > 0; sure--){
 	system("cls");
 	printf("\n\n\n\n           ----------------------------------------------------------------\n");
	printf("          > Herhangi Bir Satis Kaydi Bulunamadi. \n");
	printf("           ----------------------------------------------------------------\n");
	printf("          > |%d| Saniye Icinde Cari Islemler Menusune Yonlendirileceksiniz.\n",sure);
	printf("           ----------------------------------------------------------------\n");
	Sleep(1000);
	system("cls");
	}	
	fclose(ptr);
	cariIslemlerMenu();
	}
}
//*******************************************************



void hastaKaydi() {
	FILE *yDosya = fopen("yonetici.txt", "r");
	char yoneticiKontrol[2];
    fscanf(yDosya, " %[^\n]s",&yoneticiKontrol);
	system("cls") ; 
	hasta h1; 
	int hasta_kontrol = 0;
	printf("Hasta kayit ekrani... \n\n")  ; 
	printf("TC         : ") ; scanf(" %[^\n]s", &h1.tc ) ;
	printf("AD-SOYAD   : ") ; scanf(" %[^\n]s", &h1.adSoyad ) ;
	printf("CINSIYET   : ") ; scanf(" %[^\n]s", &h1.cinsiyet ) ;
	printf("ADRES      : ") ; scanf(" %[^\n]s", &h1.adres ) ;
	printf("TELEFON    : ") ; scanf(" %[^\n]s", &h1.tel ) ;
	struct hasta hasta_tc;
	FILE *kptr= fopen("hastalar.dat", "r+b") ;
	if(kptr!=NULL){
		while( fread(&hasta_tc, sizeof(struct hasta), 1, kptr) !=NULL  ){
			if(strcmp(h1.tc, hasta_tc.tc) == 0){
		hasta_kontrol = 1;
	}
		}
			}
	if(hasta_kontrol == 1){
		//system("cls");
		printf("\nBu tc adi baska hastaya ait!!! Lutfen tekrar deneyiniz.\n");
		Sleep(2000);
		hastaKaydi();
	}else{
		FILE *ptr= fopen("hastalar.dat", "a+b" ) ; 
		fwrite(&h1, sizeof(hasta), 1, ptr) ;  
		fclose(ptr) ;
		printf("Hasta kaydi tamamlandi. \n") ;
		printf("Hasta menusune yonlendiriliyorsunuz... \n") ;
		Sleep(1000);
		system("cls");
		if(yoneticiKontrol[0] == '2'){//2 = personel
			hastaPersonelMenu();
		}else{
			hastaMenu();
		}
	}		
		
}

void hastaListele() {
	FILE *yDosya = fopen("yonetici.txt", "r");
	char yoneticiKontrol[2];
    fscanf(yDosya, " %[^\n]s",&yoneticiKontrol);
	system("cls") ;
	char tus; 
	printf("Hasta listesi \n\n") ; 
	hasta h1; 
	FILE *ptr= fopen("hastalar.dat", "r+b" ) ; 
	
	if( ptr!=NULL ){
		printf( "%-12s%-20s%-17s%-11s%-75s\n", "TC", "AD-SOYAD", "CINSIYET", "TELEFON","ADRES"); 
	while( fread( &h1, sizeof(hasta ), 1, ptr ) !=NULL){
		printf("%-12s %-20s %-15c %-11s %-75s\n",h1.tc, h1.adSoyad, h1.cinsiyet, h1.tel, h1.adres) ;
		}
		fclose(ptr);
		printf("\n\n\n\nHasta menusune gitmek icin herhangi bir tusa basiniz : ");
		tus = _getch();
		system("cls");
		printf("Menuye yonlendiriliyorsunuz...\n");
		Sleep(1000);
		system("cls");
		if(yoneticiKontrol[0] == '2'){//2 = personel
			hastaPersonelMenu();
		}else{
			hastaMenu();
		}
	}else{
		int sure;
		for(sure = 3; sure > 0; sure--){
		system("cls");
		
		printf("\n\n\n\n           ----------------------------------------------------------------\n");
		printf("          > Hasta Kaydi Bulunamadi! \n");
		printf("           ----------------------------------------------------------------\n");
		printf("          > |%d| Saniye Icinde Satis Menusune Yonlendirileceksiniz.\n",sure);
		printf("           ----------------------------------------------------------------\n");
		Sleep(1000);
		system("cls");
		
		}
		if(yoneticiKontrol[0] == '2'){//2 = personel
			hastaPersonelMenu();
		}else{
			hastaMenu();
		}
	}
}

void hastaSil() {
    system("cls");
	printf("Hasta Kaydi Silme Ekrani \n \n");
	char tc[20];
	hasta h1;
	int sonuc=0;
	printf("Kisi Tc: "); scanf("%s", &tc);
	FILE *ptr = fopen("hastalar.dat","r+b");
	FILE *yptr = fopen("yedek.dat","w+b");
	
	while( fread(&h1, sizeof(hasta ), 1, ptr) != NULL)
	{
		if( strcmp( tc, h1.tc) == 0)
		{
		 sonuc = 1;
		}
		else
		{
		fwrite(&h1, sizeof(hasta), 1, yptr) ;
		}	
	}
    fclose(ptr);
    fclose(yptr);
    
    if(sonuc == 1)
    {
    	remove("hastalar.dat");
    	rename("yedek.dat","hastalar.dat");
    	printf("%s TC Numarali Hasta Kaydi Silindi \n", tc);
    	printf("\n\n\n\nHasta menusune gitmek icin herhangi bir tusa basiniz : ");
    	char tus;
		tus = _getch();
		system("cls");
		printf("Menuye yonlendiriliyorsunuz...\n");
		Sleep(1500);
		system("cls");
		hastaMenu();
    	
	}else{
		int sure;
		for(sure = 3; sure > 0; sure--){
		system("cls");
		printf("\n\n\n\n           ----------------------------------------------------------------\n");
		printf("          > %s TC Numarali Hasta Kaydiniz Bulunamadi! \n", tc);
		printf("           ----------------------------------------------------------------\n");
		printf("          > |%d| Saniye Icinde Satis Menusune Yonlendirileceksiniz.\n",sure);
		printf("           ----------------------------------------------------------------\n");
		Sleep(1000);
		system("cls");
		}
		hastaMenu();
	}
	
}


//********************************************************
void ilacMenu(){
	int secim;
	printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              * Ilac Islemleri  *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Ilac Kaydi                 <<<\n");
    printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |2| Ilaclari Listele           <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |3| Ilac Sil                   <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |4| Yan Etki Menusu            <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Ana Menuye Don             <<<\n");
	printf("           ----------------------------------------------------------------\n");
    printf("\n           |Seciminizi girin : ");
	
	
	if(scanf("%d", &secim) == 1){
	
	switch (secim) {
            case 1:
                ilacKaydi();
                break;
            case 2:
                ilacListele();
                break;
            case 3:
				ilacSil();
				break;
			case 4:
				system("cls");
				BelirtilerMenusu();
				
				break;
            case 0:
                system("cls");
                yoneticiAnaMenu();
            default:
            	system("cls");
				hataliGirisText();
				ilacMenu();
        }
    }else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            system("cls");
            ilacMenu();
		}
}

void ilacPersonelMenu(){
	int secim;
	printf("\n                              *******************");
	printf("\n                              *                 *");
	printf("\n                              * Ilac Islemleri  *\n");
	printf("                              *                 *\n");
	printf("                              *******************\n\n");
	printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |1| Ilac Kaydi                 <<<\n");
    printf("           ----------------------------------------------------------------\n");
    printf("           >>>                     |2| Ilaclari Listele           <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |3| Yan Etki Menusu            <<<\n");
	printf("           ----------------------------------------------------------------\n");
	printf("           >>>                     |0| Ana Menuye Don             <<<\n");
	printf("           ----------------------------------------------------------------\n");
	
    printf("\n           |Seciminizi girin : ");
	printf("Seciminizi girin: ");
	
	if(scanf("%d", &secim) == 1){
	
	switch (secim) {
            case 1:
                ilacKaydi();
                break;
            case 2:
                ilacListele();
                break;
        	case 3:
        		
                system("cls");
        		BelirtilerMenusu();
        		break;
            case 0:
            	printf("Kullanici cikisi yapiliyor...\n");
                system("cls");
                personelAnaMenu();
            default:
            	system("cls");
				hataliGirisText();
				ilacPersonelMenu();
        }
    }else{
        	system("cls");
        	hataliGirisText();
            //Hatal� giri�i temizleme
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            system("cls");
            ilacPersonelMenu();
		}
}





void ilacKaydi() {
	FILE *yDosya = fopen("yonetici.txt", "r");
	char yoneticiKontrol[2];
    fscanf(yDosya, " %[^\n]s",&yoneticiKontrol);
    system("cls");
    ilac i1;
    int barkodKontrol = 0;
    printf("Ilac Kayit Ekrani\n");
    printf("Barkod Numarasi  : "); scanf(" %s",&i1.barkod);
	printf("Ilac Adi         : "); scanf(" %[^\n]s",&i1.ilacAdi);
    printf("Uretici Firma    : "); scanf(" %[^\n]s",&i1.ureticiFirma);
    printf("Stok Adedi(Kutu) : "); scanf(" %d",&i1.adet);
    printf("Ilac Fiyatini girerken kusurati icin '.'(nokta)isaretini kullaniniz\n"); 
    printf("Ilac Fiyati      : "); scanf(" %f",&i1.fiyat);
	Sleep(750);
	system("cls");
	
	
	
	
    struct ilac ilacBarkod;
    FILE *sptr = fopen("ilaclar.dat", "r+b");
    if (sptr != NULL) {
        while (fread(&ilacBarkod, sizeof(struct ilac), 1, sptr) != NULL) {
            if (strcmp( ilacBarkod.barkod, i1.barkod  ) ==0){
                barkodKontrol = 1;
                break;
            }
        }
        fclose(sptr);
    }

    if (barkodKontrol == 1) {
        printf("\nBu barkod numarasina sahip ilac zaten kayitli! Lutfen baska bir barkod numaras� kullaniniz.\n");
        Sleep(2000);
        system("cls");
        if(yoneticiKontrol[0] == '2'){//2 = personel
			ilacPersonelMenu();
		}else{
			ilacMenu();
		}
    } else {
        FILE *ptr = fopen("ilaclar.dat", "a+b");
        fwrite(&i1, sizeof(ilac), 1, ptr);
        fclose(ptr);
        YanEtkiEkle(i1.barkod);
        printf("Ilac kaydi yapildi.\n");
        Sleep(1000);
        system("cls");
        if(yoneticiKontrol[0] == '2'){//2 = personel
			ilacPersonelMenu();
		}else{
			ilacMenu();
		}
    }
}

void ilacListele() {
system("cls");
	FILE *yDosya = fopen("yonetici.txt", "r");
	char yoneticiKontrol[2];
    fscanf(yDosya, " %[^\n]s",&yoneticiKontrol);
    
    ilac i1;
    char tus;
    printf("Ilac Listesi\n");
    
    FILE *ptr=fopen("ilaclar.dat", "r+b");
    if( ptr!=NULL ){
    	printf("%-12s%-20s%-20s%-12s%-10s\n", "BARKOD NO","ILAC ADI","FIRMA ADI","ADET(KUTU)", "FIYAT (TL)" );
    while(	fread(&i1,	sizeof(ilac), 1 ,ptr) !=NULL ){
        printf("%-12s%-20s%-20s%-12d%.2f TL\n",i1.barkod,i1.ilacAdi,i1.ureticiFirma,i1.adet,i1.fiyat );
		}
		fclose(ptr);
		printf("\n\n\n\nIlac menusune gitmek icin herhangi bir tusa basiniz : ");
		tus = _getch();
		system("cls");
		printf("Menuye yonlendiriliyorsunuz...\n");
		Sleep(1000);
		system("cls");
		if(yoneticiKontrol[0] == '2'){//2 = personel
			ilacPersonelMenu();
		}else{
			ilacMenu();
		}
	}
    else{
		int sure;
		for(sure = 3; sure > 0; sure--){
		system("cls");
		printf("\n\n\n\n           ----------------------------------------------------------------\n");
		printf("          > Ilac Kaydi Bulunamadi. \n");
		printf("           ----------------------------------------------------------------\n");
		printf("          > |%d| Saniye Icinde Ilac Menusune Yonlendirileceksiniz.\n",sure);
		printf("           ----------------------------------------------------------------\n");
		Sleep(1000);
		system("cls");
		}
		fclose(ptr);
		if(yoneticiKontrol[0] == '2'){//2 = personel
			ilacPersonelMenu();
		}else{
			ilacMenu();
		}
	} 	
}

void ilacSil() {
   	system("cls");
	printf("Ilac Kaydi Silme Ekrani \n \n");
	char barkod[20];
	int sonuc=0;
	ilac i1;
	printf("Ilac Barkod: "); scanf("%s", &barkod);
	FILE *ptr = fopen("ilaclar.dat","r+b");
	FILE *yptr = fopen("yedek.dat","w+b");
	
	while( fread(&i1, sizeof(ilac ), 1, ptr) != NULL)
	{
		if(strcmp(barkod,i1.barkod) == 0){
		 sonuc = 1;
		}
		else
		{
		fwrite(&i1, sizeof(ilac), 1, yptr) ;
		}	
	}
    fclose(ptr);
    fclose(yptr);
    
    if(sonuc == 1)
    {
    	remove("ilaclar.dat");
    	rename("yedek.dat","ilaclar.dat");
    	printf("%s Barkod Numarali ilac Kaydi Silindi \n", barkod);
    	printf("\n\n\n\Ilac menusune gitmek icin herhangi bir tusa basiniz : ");
    	char tus;
		tus = _getch();
		system("cls");
		printf("Menuye yonlendiriliyorsunuz...\n");
		Sleep(1500);
		system("cls");
		ilacMenu();
    	
	}else{
		int sure;
		for(sure = 3; sure > 0; sure--){
		system("cls");
		printf("\n\n\n\n           ----------------------------------------------------------------\n");
		printf("          > %s Barkod Numarali Ilac Kaydiniz Bulunamadi! \n", barkod);
		printf("           ----------------------------------------------------------------\n");
		printf("          > |%d| Saniye Icinde Ilac Menusune Yonlendirileceksiniz.\n",sure);
		printf("           ----------------------------------------------------------------\n");
		Sleep(1000);
		system("cls");
		}
		ilacMenu();
	}

}


void siringaac()
{
	printf("              _______   \n");
   
    printf("             |_______|  \n");
   		
    printf("               |   |    \n");
   
    printf("               |   |    \n");
 
    printf("               |   |    \n");

    printf("              _|___|_   \n");
  
    printf("             |       |  \n");
   
    printf("             |__5    |  \n");
 
    printf("             |__4    |  \n");
    
    printf("             |__3    |  \n");
   
    printf("             |__2    |  \n");
  
    printf("             |__1    |  \n");

    printf("             |       |  \n");
    
    printf("             |_______|  \n");
    
    printf("              \\     /   \n");
   
    printf("               \\   /    \n");
  
    printf("                \\ /     \n");
  
    printf("                 |      \n");
    
    printf("                 |      \n");
    
    printf("                 |      \n");
    
    printf("                        \n");
   
    
  
}

void siringakapa()
{
	printf("\n \n");
	printf("              _______   \n");
  
    printf("             |_______|  \n");
   	
    printf("               |   |    \n");
   
    printf("              _|___|_   \n");

    printf("             |       |  \n");
   
    printf("             |__5    |  \n");
    
    printf("             |__4    |  \n");
    
    printf("             |__3    |  \n");

    printf("             |__2    |  \n");

    printf("             |__1    |  \n");
   
    printf("             |       |  \n");
   
    printf("             |_______|  \n");

    printf("              \\     /   \n");
  
    printf("               \\   /    \n");
    
    printf("                \\ /     \n");
    
    printf("                 |      \n");
   
    printf("                 |      \n");
    
    printf("                 |      \n");
   
    printf("                 0       \n");
    printf("                0 0      \n");
    printf("               0   0	  \n");
	printf("              0     0    \n");
    printf("               0 0 0     \n");
   	printf("                        \n");
    printf("                        \n");
    printf("                        \n");
    
}

int main(int argc, char *argv[]) {
	
	char animation[] = "|/-\\";
    char *art[] = {
        " E  C  Z  A  N  E    O  T  O  M  A  S  Y  O  N  U  "
    };
    
 /*   printf("    _______   \n");
    Sleep(200);
    printf("   |_______|  \n");
    Sleep(200);		
    printf("     |   |    \n");
    Sleep(200);
    printf("     |   |    \n");
    Sleep(200);
    printf("     |   |    \n");
    Sleep(200);
    printf("    _|___|_   \n");
    Sleep(200);
    printf("   |       |  \n");
    Sleep(200);
    printf("   |__5    |  \n");
    Sleep(200);
    printf("   |__4    |  \n");
    Sleep(200);
    printf("   |__3    |  \n");
    Sleep(200);
    printf("   |__2    |  \n");
    Sleep(200);
    printf("   |__1    |  \n");
    Sleep(200);
    printf("   |       |  \n");
    Sleep(200);
    printf("   |_______|  \n");
    Sleep(200);
    printf("    \\     /   \n");
    Sleep(200);
    printf("     \\   /    \n");
    Sleep(200);
    printf("      \\ /     \n");
    Sleep(200);
    printf("       |      \n");
    Sleep(200);
    printf("       |      \n");
    Sleep(200);
    printf("       |      \n");
    Sleep(200);
    printf("              \n");
    Sleep(700);
    
    system("cls");*/
    
    siringaac();
    Sleep(500);
    system("cls");
    siringakapa();
    
    Sleep(500);
    system("cls");
    siringaac();
    Sleep(500);
    system("cls");
    siringakapa();
    Sleep(500);
    system("cls");
 
    siringaac();
    Sleep(500);
    system("cls");
    siringakapa();
    
    Sleep(700);
    system("cls");
    siringaac();
    Sleep(500);
    system("cls");
    siringakapa();
    
    Sleep(500);
    system("cls");
    
    
    int i;
    for (i = 0; i < 1; i++) {
        printf("%s\n", art[i]);
    }
    printf("\nProgram baslatiliyor...\n");

    for (i = 0; i < 21; i++) {
        printf("\r%c %d%%", animation[i % 4], i * 5);
        fflush(stdout);
        usleep(200000); // 200ms bekletme
    }

    printf("\n\n\n\nGiris basarili. Hos geldiniz!\n");
    Sleep(3000);
    
    system("cls");


    girisMenu();
	return 0;
}
